﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BIOC_mrowki.Models
{
    public class Ant : Field
    {
        private const int _lostFeromon = 10;

        public override Color Color => Color.Khaki;
        public Ant(int x, int y) : base(x, y)
        {

        }

        public void Move(Labirynth labirynth, Point to)
        {
            labirynth.Board[to.X, to.Y] = this;
            labirynth.Board[X, Y] = new Feromon(X,Y, _lostFeromon);
            X = to.X;
            Y = to.Y;

        }

        public void selectMove(Labirynth labirynth)
        {
            var points = getPossibleMoves(labirynth);
            var poss = new Random();
            var possInt = poss.Next(0, 99);
            var propability = 100 / points.Count;

            for (int i = 0; i < points.Count; i++)
            {
                if (possInt >= i * propability && possInt <= (i+1)* propability)
                {
                    Move(labirynth, points[i]);
                    return;
                }
            }
           
          
        }

        public List<Point> getPossibleMoves(Labirynth labirynth)
        {

            var points = new List<Point>(); 
            if (X != labirynth.SizeX - 1 &&!(labirynth.Board[X+1,Y] is Wall))
            {
                points.Add(new Point(X + 1, Y));
            }
            if (X != 0 && !(labirynth.Board[X - 1, Y] is Wall))
            {
                points.Add(new Point(X - 1, Y));

            }
            if (Y != 0 && !(labirynth.Board[X, Y-1] is Wall))
            {
                points.Add(new Point(X, Y - 1));

            }
            if (Y != labirynth.SizeY -1 && !(labirynth.Board[X, Y + 1] is Wall))
            {
                points.Add(new Point(X, Y + 1));

            }

            return points;

        }
    }

}
